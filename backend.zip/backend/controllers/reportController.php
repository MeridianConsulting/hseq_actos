<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../utils/mailer.php';
require_once __DIR__ . '/pdfController.php';

class ReportController {
    private $conn;
    
    // Constantes para validación de ENUMs
    private const TIPOS_REPORTE_VALIDOS = ['hallazgos', 'incidentes', 'conversaciones', 'pqr'];
    private const ESTADOS_VALIDOS = ['pendiente', 'en_revision', 'aprobado', 'rechazado'];
    private const TIPOS_HALLAZGO_VALIDOS = ['accion_mejoramiento', 'aspecto_positivo', 'condicion_insegura', 'acto_inseguro'];
    private const ESTADOS_CONDICION_VALIDOS = ['abierta', 'cerrada'];
    private const GRADOS_CRITICIDAD_VALIDOS = ['bajo', 'medio', 'alto', 'critico'];
    private const TIPOS_AFECTACION_VALIDOS = ['personas', 'medio_ambiente', 'instalaciones', 'vehiculos', 'seguridad_procesos', 'operaciones'];
    private const TIPOS_CONVERSACION_VALIDOS = ['reflexion', 'conversacion'];
    private const TIPOS_PQR_VALIDOS = ['peticion', 'queja', 'reclamo', 'inquietud'];
    
    public function __construct() {
        global $db;
        if (!$db) {
            throw new Exception("No se pudo establecer conexión con la base de datos");
        }
        $this->conn = $db;
        
        // Verificar que la conexión esté activa
        if ($this->conn->connect_error) {
            throw new Exception("Error de conexión a la base de datos: " . $this->conn->connect_error);
        }
    }
    
    /**
     * Validar campos ENUM según el tipo de reporte
     */
    private function validateEnumFields($data, $tipoReporte) {
        $errors = [];
        
        // Validar tipo de reporte
        if (!in_array($data['tipo_reporte'], self::TIPOS_REPORTE_VALIDOS)) {
            $errors[] = "Tipo de reporte inválido. Valores permitidos: " . implode(', ', self::TIPOS_REPORTE_VALIDOS);
        }
        
        // Validar campos específicos según tipo de reporte
        switch ($tipoReporte) {
            case 'hallazgos':
                if (isset($data['tipo_hallazgo']) && !in_array($data['tipo_hallazgo'], self::TIPOS_HALLAZGO_VALIDOS)) {
                    $errors[] = "Tipo de hallazgo inválido. Valores permitidos: " . implode(', ', self::TIPOS_HALLAZGO_VALIDOS);
                }
                if (isset($data['estado_condicion']) && !in_array($data['estado_condicion'], self::ESTADOS_CONDICION_VALIDOS)) {
                    $errors[] = "Estado de condición inválido. Valores permitidos: " . implode(', ', self::ESTADOS_CONDICION_VALIDOS);
                }
                break;
                
            case 'incidentes':
                if (isset($data['grado_criticidad']) && !in_array($data['grado_criticidad'], self::GRADOS_CRITICIDAD_VALIDOS)) {
                    $errors[] = "Grado de criticidad inválido. Valores permitidos: " . implode(', ', self::GRADOS_CRITICIDAD_VALIDOS);
                }
                if (isset($data['tipo_afectacion']) && !in_array($data['tipo_afectacion'], self::TIPOS_AFECTACION_VALIDOS)) {
                    $errors[] = "Tipo de afectación inválido. Valores permitidos: " . implode(', ', self::TIPOS_AFECTACION_VALIDOS);
                }
                break;
                
            case 'conversaciones':
                if (isset($data['tipo_conversacion']) && !in_array($data['tipo_conversacion'], self::TIPOS_CONVERSACION_VALIDOS)) {
                    $errors[] = "Tipo de conversación inválido. Valores permitidos: " . implode(', ', self::TIPOS_CONVERSACION_VALIDOS);
                }
                break;
                
            case 'pqr':
                if (isset($data['tipo_pqr']) && !in_array($data['tipo_pqr'], self::TIPOS_PQR_VALIDOS)) {
                    $errors[] = "Tipo de PQR inválido. Valores permitidos: " . implode(', ', self::TIPOS_PQR_VALIDOS);
                }
                break;
        }
        
        return $errors;
    }
    
    /**
     * Sanitizar datos de entrada
     */
    private function sanitizeInput($data) {
        $sanitized = [];
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $sanitized[$key] = htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
            } else {
                $sanitized[$key] = $value;
            }
        }
        return $sanitized;
    }
    
    /**
     * Crear un nuevo reporte
     */
    public function createReport($data) {
        try {
            // Limpieza de logs visibles: no registrar datos del usuario en producción
            
            // Verificar conexión a la base de datos
            if (!$this->conn || $this->conn->connect_error) {
                throw new Exception("Error de conexión a la base de datos");
            }
            
            // Sanitizar datos de entrada
            $data = $this->sanitizeInput($data);
            
            // Validar datos requeridos
            if (!isset($data['tipo_reporte']) || !isset($data['id_usuario'])) {
                return [
                    'success' => false,
                    'message' => 'Faltan campos requeridos: tipo_reporte e id_usuario'
                ];
            }
            
            // Validar campos ENUM
            $enumErrors = $this->validateEnumFields($data, $data['tipo_reporte']);
            if (!empty($enumErrors)) {
                return [
                    'success' => false,
                    'message' => 'Errores de validación: ' . implode(', ', $enumErrors)
                ];
            }
            
            // Validar campos específicos según tipo de reporte
            $validationErrors = $this->validateReportFields($data, $data['tipo_reporte']);
            if (!empty($validationErrors)) {
                return [
                    'success' => false,
                    'message' => 'Errores de validación: ' . implode(', ', $validationErrors)
                ];
            }
            
            // Preparar la consulta SQL base
            $sql = "INSERT INTO reportes (
                id_usuario, 
                tipo_reporte,
                telefono_contacto,
                correo_contacto,
                tipo_pqr,
                asunto, 
                descripcion_general,
                fecha_evento,
                lugar_hallazgo,
                lugar_hallazgo_otro,
                tipo_hallazgo,
                descripcion_hallazgo,
                recomendaciones,
                estado_condicion,
                grado_criticidad,
                ubicacion_incidente,
                hora_evento,
                tipo_afectacion,
                descripcion_incidente,
                tipo_conversacion,
                sitio_evento_conversacion,
                lugar_hallazgo_conversacion,
                lugar_hallazgo_conversacion_otro,
                descripcion_conversacion,
                asunto_conversacion
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $this->conn->prepare($sql);
            
            if (!$stmt) {
                throw new Exception("Error preparando la consulta: " . $this->conn->error);
            }
            
            // Extraer valores a variables para bind_param (SOLUCIÓN AL PROBLEMA)
            $id_usuario = $data['id_usuario'];
            $tipo_reporte = $data['tipo_reporte'];
            $telefono_contacto = $data['telefono_contacto'] ?? null;
            $correo_contacto = $data['correo_contacto'] ?? null;
            $tipo_pqr = $data['tipo_pqr'] ?? null;
            $asunto = $data['asunto'] ?? $data['asunto_conversacion'] ?? null;
            $descripcion_general = $data['descripcion_general'] ?? null;
            $fecha_evento = $data['fecha_evento'] ?? null;
            $lugar_hallazgo = $data['lugar_hallazgo'] ?? null;
            $lugar_hallazgo_otro = $data['lugar_hallazgo_otro'] ?? null;
            $tipo_hallazgo = $data['tipo_hallazgo'] ?? null;
            $descripcion_hallazgo = $data['descripcion_hallazgo'] ?? null;
            $recomendaciones = $data['recomendaciones'] ?? null;
            $estado_condicion = $data['estado_condicion'] ?? null;
            $grado_criticidad = $data['grado_criticidad'] ?? null;
            $ubicacion_incidente = $data['ubicacion_incidente'] ?? null;
            $hora_evento = $data['hora_evento'] ?? null;
            $tipo_afectacion = $data['tipo_afectacion'] ?? null;
            $descripcion_incidente = $data['descripcion_incidente'] ?? null;
            $tipo_conversacion = $data['tipo_conversacion'] ?? null;
            $sitio_evento_conversacion = $data['sitio_evento_conversacion'] ?? null;
            $lugar_hallazgo_conversacion = $data['lugar_hallazgo_conversacion'] ?? null;
            $lugar_hallazgo_conversacion_otro = $data['lugar_hallazgo_conversacion_otro'] ?? null;
            $descripcion_conversacion = $data['descripcion_conversacion'] ?? null;
            $asunto_conversacion = $data['asunto_conversacion'] ?? null;
            
            // Bind de parámetros usando variables (no expresiones de array)
            $stmt->bind_param("issssssssssssssssssssssss",
                $id_usuario,
                $tipo_reporte,
                $telefono_contacto,
                $correo_contacto,
                $tipo_pqr,
                $asunto,
                $descripcion_general,
                $fecha_evento,
                $lugar_hallazgo,
                $lugar_hallazgo_otro,
                $tipo_hallazgo,
                $descripcion_hallazgo,
                $recomendaciones,
                $estado_condicion,
                $grado_criticidad,
                $ubicacion_incidente,
                $hora_evento,
                $tipo_afectacion,
                $descripcion_incidente,
                $tipo_conversacion,
                $sitio_evento_conversacion,
                $lugar_hallazgo_conversacion,
                $lugar_hallazgo_conversacion_otro,
                $descripcion_conversacion,
                $asunto_conversacion
            );
            
            // Ejecutar la consulta
            if (!$stmt->execute()) {
                throw new Exception("Error ejecutando la consulta: " . $stmt->error);
            }
            
            $reportId = $this->conn->insert_id;
            
            $stmt->close();

            // Notificar creación de reporte (no bloquear si mail falla)
            try { $this->notifyReportEvent($reportId, 'creacion', $data); } catch (Exception $e) { /* silencioso */ }

            return [
                'success' => true,
                'message' => 'Reporte creado exitosamente',
                'report_id' => $reportId
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al crear el reporte: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Validar campos específicos según tipo de reporte
     */
    private function validateReportFields($data, $tipoReporte) {
        $errors = [];
        
        // Validar fecha_evento (formato YYYY-MM-DD)
        if (isset($data['fecha_evento']) && !empty($data['fecha_evento'])) {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['fecha_evento'])) {
                $errors[] = "Formato de fecha inválido. Use YYYY-MM-DD";
            }
        }
        
        // Validar hora_evento (formato HH:MM:SS)
        if (isset($data['hora_evento']) && !empty($data['hora_evento'])) {
            if (!preg_match('/^\d{2}:\d{2}:\d{2}$/', $data['hora_evento'])) {
                $errors[] = "Formato de hora inválido. Use HH:MM:SS";
            }
        }
        
        // Validar campos específicos según tipo
        switch ($tipoReporte) {
            case 'hallazgos':
                if (empty($data['asunto'])) {
                    $errors[] = "El campo 'asunto' es requerido para hallazgos";
                }
                if (empty($data['lugar_hallazgo'])) {
                    $errors[] = "El campo 'lugar_hallazgo' es requerido para hallazgos";
                }
                if (empty($data['tipo_hallazgo'])) {
                    $errors[] = "El campo 'tipo_hallazgo' es requerido para hallazgos";
                }
                if (empty($data['descripcion_hallazgo'])) {
                    $errors[] = "El campo 'descripcion_hallazgo' es requerido para hallazgos";
                }
                if (empty($data['estado_condicion'])) {
                    $errors[] = "El campo 'estado_condicion' es requerido para hallazgos";
                }
                break;
                
            case 'incidentes':
                if (empty($data['asunto'])) {
                    $errors[] = "El campo 'asunto' es requerido para incidentes";
                }
                if (empty($data['grado_criticidad'])) {
                    $errors[] = "El campo 'grado_criticidad' es requerido para incidentes";
                }
                if (empty($data['ubicacion_incidente'])) {
                    $errors[] = "El campo 'ubicacion_incidente' es requerido para incidentes";
                }
                if (empty($data['tipo_afectacion'])) {
                    $errors[] = "El campo 'tipo_afectacion' es requerido para incidentes";
                }
                if (empty($data['descripcion_incidente'])) {
                    $errors[] = "El campo 'descripcion_incidente' es requerido para incidentes";
                }
                break;
                
            case 'conversaciones':
                if (empty($data['asunto_conversacion'])) {
                    $errors[] = "El campo 'asunto_conversacion' es requerido para conversaciones";
                }
                if (empty($data['tipo_conversacion'])) {
                    $errors[] = "El campo 'tipo_conversacion' es requerido para conversaciones";
                }
                if (empty($data['sitio_evento_conversacion'])) {
                    $errors[] = "El campo 'sitio_evento_conversacion' es requerido para conversaciones";
                }
                if (empty($data['descripcion_conversacion'])) {
                    $errors[] = "El campo 'descripcion_conversacion' es requerido para conversaciones";
                }
                break;
                
            case 'pqr':
                if (empty($data['asunto'])) {
                    $errors[] = "El campo 'asunto' es requerido para PQR";
                }
                if (empty($data['tipo_pqr'])) {
                    $errors[] = "El campo 'tipo_pqr' es requerido para PQR";
                }
                if (empty($data['telefono_contacto'])) {
                    $errors[] = "El campo 'telefono_contacto' es requerido para PQR";
                }
                if (empty($data['correo_contacto'])) {
                    $errors[] = "El campo 'correo_contacto' es requerido para PQR";
                }
                if (empty($data['descripcion_hallazgo'])) {
                    $errors[] = "El campo 'descripcion_hallazgo' es requerido para PQR";
                }
                break;
        }
        
        return $errors;
    }
    
    /**
     * Subir evidencia para un reporte
     */
    public function uploadEvidence($reportId, $evidenceData) {
        try {
            // Validar existencia del reporte
            $sql = "SELECT id FROM reportes WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("i", $reportId);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                return [ 'success' => false, 'message' => 'Reporte no encontrado' ];
            }
            $stmt->close();

            // Validar estructura de datos
            if (!isset($evidenceData['data']) || !isset($evidenceData['type']) || !isset($evidenceData['extension'])) {
                return [ 'success' => false, 'message' => 'Datos de evidencia incompletos' ];
            }

            // Decodificar base64 de manera segura
            $fileData = base64_decode($evidenceData['data'], true);
            if ($fileData === false) {
                return [ 'success' => false, 'message' => 'Error al decodificar datos base64' ];
            }

            // Detectar MIME real a partir del contenido (con fallback si fileinfo no está disponible)
            $detectedType = '';
            if (class_exists('finfo')) {
                try {
                    $fi = new finfo(FILEINFO_MIME_TYPE);
                    $detectedType = $fi->buffer($fileData) ?: '';
                } catch (Throwable $e) {
                    $detectedType = '';
                }
            }

            // Listas de tipos permitidos
            $allowedTypes = [
                'image/jpeg','image/png','image/gif','image/webp',
                'application/pdf',
                'application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            ];
            if (!in_array($detectedType, $allowedTypes, true)) {
                // Intentar usar el tipo declarado si es permitido
                if (in_array($evidenceData['type'], $allowedTypes, true)) {
                    $detectedType = $evidenceData['type'];
                } else {
                    // Detectar si es imagen por contenido aunque no tengamos MIME
                    if (function_exists('getimagesizefromstring')) {
                        $imgInfo = @getimagesizefromstring($fileData);
                        if (is_array($imgInfo)) {
                            $detectedType = 'image/jpeg';
                        }
                    }
                }
            }
            if (!in_array($detectedType, $allowedTypes, true)) {
                return [ 'success' => false, 'message' => 'Tipo de archivo no permitido' ];
            }

            // Validar tamaño (si viene proveído)
            $maxSize = 10 * 1024 * 1024; // 10 MB
            if (isset($evidenceData['size']) && (int)$evidenceData['size'] > $maxSize) {
                return [ 'success' => false, 'message' => 'El archivo es demasiado grande. Máximo 10MB' ];
            }

            // Asegurar directorio de subida
            $uploadDir = __DIR__ . '/../uploads/';
            if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0755, true); }

            // Determinar si es imagen y aplicar compresión/redimensionado
            $isImage = str_starts_with($detectedType, 'image/');
            $targetExtension = strtolower($evidenceData['extension'] ?: 'bin');

            $finalBinary = $fileData;
            $finalMime = $detectedType ?: $evidenceData['type'];

            if ($isImage) {
                // Cargar imagen desde binario (GD)
                $img = function_exists('imagecreatefromstring') ? @imagecreatefromstring($fileData) : false;
                if ($img !== false) {
                    $origW = imagesx($img);
                    $origH = imagesy($img);
                    $maxDim = 1920; // límite de dimensión
                    $scale = 1.0;
                    if ($origW > $maxDim || $origH > $maxDim) {
                        $scale = min($maxDim / max(1,$origW), $maxDim / max(1,$origH));
                    }
                    $newW = (int)floor($origW * $scale);
                    $newH = (int)floor($origH * $scale);
                    if ($newW < 1) { $newW = $origW; }
                    if ($newH < 1) { $newH = $origH; }

                    $dst = function_exists('imagecreatetruecolor') ? imagecreatetruecolor($newW, $newH) : null;
                    if ($dst) {
                    // Fondo blanco para preservar transparencia al convertir a JPEG
                        $white = imagecolorallocate($dst, 255, 255, 255);
                        imagefill($dst, 0, 0, $white);
                        imagecopyresampled($dst, $img, 0, 0, 0, 0, $newW, $newH, $origW, $origH);

                    // Exportar como JPEG con calidad 85
                        ob_start();
                        if (function_exists('imagejpeg')) {
                            imagejpeg($dst, null, 85);
                        }
                        $compressed = ob_get_clean();
                        imagedestroy($dst);
                        imagedestroy($img);
                        if ($compressed !== false && strlen($compressed) > 0) {
                            $finalBinary = $compressed;
                            $finalMime = 'image/jpeg';
                            $targetExtension = 'jpg';
                        }
                    } else {
                        // Si no hay GD, mantener original
                        imagedestroy($img);
                    }
                }
            }

            // Nombre final de archivo
            $fileName = 'evidencia_' . $reportId . '_' . time() . '_' . uniqid() . '.' . $targetExtension;
            $uploadPath = $uploadDir . $fileName;

            // Escribir a disco
            if (file_put_contents($uploadPath, $finalBinary) === false) {
                return [ 'success' => false, 'message' => 'Error al guardar el archivo' ];
            }

            // Guardar referencia en BD
            $sql = "INSERT INTO evidencias (id_reporte, tipo_archivo, url_archivo) VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($sql);
            $tipoParaGuardar = $finalMime ?: $evidenceData['type'];
            $stmt->bind_param("iss", $reportId, $tipoParaGuardar, $fileName);
            if (!$stmt->execute()) {
                @unlink($uploadPath);
                throw new Exception("Error guardando referencia en base de datos: " . $stmt->error);
            }
            $evidenceId = $this->conn->insert_id;
            $stmt->close();

            // Limpieza de memoria
            unset($fileData, $finalBinary);
            if (function_exists('gc_collect_cycles')) { gc_collect_cycles(); }

            return [
                'success' => true,
                'message' => 'Evidencia subida exitosamente',
                'evidence_id' => $evidenceId,
                'file_name' => $fileName
            ];

        } catch (Exception $e) {
            return [ 'success' => false, 'message' => 'Error al subir evidencia: ' . $e->getMessage() ];
        }
    }
    
    /**
     * Obtener mensaje de error de subida de archivo
     */
    private function getUploadErrorMessage($errorCode) {
        switch ($errorCode) {
            case UPLOAD_ERR_INI_SIZE:
                return 'El archivo excede el tamaño máximo permitido por el servidor';
            case UPLOAD_ERR_FORM_SIZE:
                return 'El archivo excede el tamaño máximo permitido por el formulario';
            case UPLOAD_ERR_PARTIAL:
                return 'El archivo se subió parcialmente';
            case UPLOAD_ERR_NO_FILE:
                return 'No se subió ningún archivo';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'Falta la carpeta temporal';
            case UPLOAD_ERR_CANT_WRITE:
                return 'Error al escribir el archivo en disco';
            case UPLOAD_ERR_EXTENSION:
                return 'Una extensión de PHP detuvo la subida del archivo';
            default:
                return 'Error desconocido al subir archivo';
        }
    }
    
    /**
     * Obtener reportes por usuario
     */
    public function getReportsByUser($userId) {
        try {
            $sql = "SELECT r.*, u.nombre as nombre_usuario, u.Proyecto as proyecto_usuario 
                    FROM reportes r 
                    JOIN usuarios u ON r.id_usuario = u.id 
                    WHERE r.id_usuario = ? 
                    ORDER BY r.creado_en DESC";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            
            $result = $stmt->get_result();
            $reports = [];
            
            while ($row = $result->fetch_assoc()) {
                $reports[] = $row;
            }
            
            $stmt->close();
            
            return [
                'success' => true,
                'reports' => $reports
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al obtener reportes: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Obtener todos los reportes (para coordinadores y admin)
     */
    public function getAllReports($filters = []) {
        try {
            // Base query con JOIN para obtener el nombre del revisor asignado
            $baseSql = "FROM reportes r 
                        JOIN usuarios u ON r.id_usuario = u.id 
                        LEFT JOIN usuarios revisor ON r.revisado_por = revisor.id";
            $whereConditions = [];
            $params = [];
            $types = "";

            // Filtros exactos
            if (!empty($filters['tipo_reporte'])) {
                $whereConditions[] = "r.tipo_reporte = ?";
                $params[] = $filters['tipo_reporte'];
                $types .= "s";
            }
            if (!empty($filters['estado'])) {
                $whereConditions[] = "r.estado = ?";
                $params[] = $filters['estado'];
                $types .= "s";
            }
            if (!empty($filters['user_id'])) {
                $whereConditions[] = "r.id_usuario = ?";
                $params[] = (int)$filters['user_id'];
                $types .= "i";
            }
            if (!empty($filters['grado_criticidad'])) {
                $whereConditions[] = "r.grado_criticidad = ?";
                $params[] = $filters['grado_criticidad'];
                $types .= "s";
            }
            if (!empty($filters['tipo_afectacion'])) {
                $whereConditions[] = "r.tipo_afectacion = ?";
                $params[] = $filters['tipo_afectacion'];
                $types .= "s";
            }
            if (!empty($filters['proyecto'])) {
                // Si el filtro contiene comas, es una lista de valores
                if (strpos($filters['proyecto'], ',') !== false) {
                    $proyectos = explode(',', $filters['proyecto']);
                    $proyectos = array_map('trim', $proyectos); // Limpiar espacios
                    $placeholders = str_repeat('?,', count($proyectos) - 1) . '?';
                    $whereConditions[] = "u.Proyecto IN ($placeholders)";
                    foreach ($proyectos as $proyecto) {
                        $params[] = $proyecto;
                        $types .= "s";
                    }
                } else {
                    // Un solo valor
                    $whereConditions[] = "u.Proyecto = ?";
                    $params[] = $filters['proyecto'];
                    $types .= "s";
                }
            }
            if (!empty($filters['revisado_por'])) {
                $whereConditions[] = "r.id_usuario = ?";
                $params[] = (int)$filters['revisado_por'];
                $types .= "i";
            }

            // Filtros por fecha (usamos creado_en)
            if (!empty($filters['date_from'])) {
                $whereConditions[] = "DATE(r.creado_en) >= ?";
                $params[] = $filters['date_from'];
                $types .= "s";
            }
            if (!empty($filters['date_to'])) {
                $whereConditions[] = "DATE(r.creado_en) <= ?";
                $params[] = $filters['date_to'];
                $types .= "s";
            }

            // Búsqueda libre (q)
            if (!empty($filters['q'])) {
                $q = '%' . $filters['q'] . '%';
                $whereConditions[] = "(r.asunto LIKE ? OR r.descripcion_general LIKE ? OR r.descripcion_incidente LIKE ? OR r.descripcion_hallazgo LIKE ? OR r.asunto_conversacion LIKE ?)";
                array_push($params, $q, $q, $q, $q, $q);
                $types .= "sssss";
            }

            $whereSql = '';
            if (!empty($whereConditions)) {
                $whereSql = ' WHERE ' . implode(' AND ', $whereConditions);
            }

            // Ordenamiento seguro
            $allowedSortBy = ['creado_en','fecha_evento','grado_criticidad','estado'];
            $sortByRequested = $filters['sort_by'] ?? 'creado_en';
            $sortBy = in_array($sortByRequested, $allowedSortBy, true) ? $sortByRequested : 'creado_en';
            $sortDir = strtolower($filters['sort_dir'] ?? 'desc');
            $sortDir = $sortDir === 'asc' ? 'ASC' : 'DESC';

            // Paginación
            $page = max(1, (int)($filters['page'] ?? 1));
            $perPage = (int)($filters['per_page'] ?? 10);
            if ($perPage <= 0) $perPage = 10;
            if ($perPage > 100) $perPage = 100;
            $offset = ($page - 1) * $perPage;

            // Total de registros
            $countSql = "SELECT COUNT(*) as total " . $baseSql . $whereSql;
            $countStmt = $this->conn->prepare($countSql);
            if (!empty($params)) {
                $countStmt->bind_param($types, ...$params);
            }
            $countStmt->execute();
            $countRes = $countStmt->get_result()->fetch_assoc();
            $total = (int)($countRes['total'] ?? 0);
            $countStmt->close();

            // Query principal
            // Inyectar LIMIT/OFFSET de forma segura (valores casteados arriba)
            $selectSql = "SELECT r.*, 
                          u.nombre as nombre_usuario, 
                          u.Proyecto as proyecto_usuario,
                          revisor.nombre as nombre_revisor,
                          revisor.correo as correo_revisor " . $baseSql . $whereSql . " ORDER BY r.$sortBy $sortDir LIMIT $perPage OFFSET $offset";
            $stmt = $this->conn->prepare($selectSql);

            if ($stmt === false) {
                throw new Exception('Error preparando consulta de listados: ' . $this->conn->error);
            }

            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }

            $stmt->execute();
            $result = $stmt->get_result();
            $reports = [];

            while ($row = $result->fetch_assoc()) {
                $reports[] = $row;
            }

            $stmt->close();

            return [
                'success' => true,
                'reports' => $reports,
                'meta' => [
                    'page' => $page,
                    'per_page' => $perPage,
                    'total' => $total,
                    'total_pages' => $perPage > 0 ? (int)ceil($total / $perPage) : 1,
                    'sort_by' => $sortBy,
                    'sort_dir' => strtolower($sortDir)
                ]
            ];

        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al obtener reportes: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Obtener un reporte específico por ID
     */
    public function getReportById($reportId) {
        try {
            $sql = "SELECT r.*, 
                    u.nombre as nombre_usuario, 
                    u.Proyecto as proyecto_usuario,
                    revisor.nombre as nombre_revisor,
                    revisor.correo as correo_revisor
                    FROM reportes r 
                    JOIN usuarios u ON r.id_usuario = u.id 
                    LEFT JOIN usuarios revisor ON r.revisado_por = revisor.id
                    WHERE r.id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("i", $reportId);
            $stmt->execute();
            
            $result = $stmt->get_result();
            $report = $result->fetch_assoc();
            
            if (!$report) {
                return [
                    'success' => false,
                    'message' => 'Reporte no encontrado'
                ];
            }
            
            // Obtener evidencias asociadas
            $sqlEvidencias = "SELECT * FROM evidencias WHERE id_reporte = ?";
            $stmtEvidencias = $this->conn->prepare($sqlEvidencias);
            $stmtEvidencias->bind_param("i", $reportId);
            $stmtEvidencias->execute();
            
            $resultEvidencias = $stmtEvidencias->get_result();
            $evidencias = [];
            
            while ($row = $resultEvidencias->fetch_assoc()) {
                $evidencias[] = $row;
            }
            
            $report['evidencias'] = $evidencias;
            
            $stmt->close();
            $stmtEvidencias->close();
            
            return [
                'success' => true,
                'report' => $report
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al obtener reporte: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Actualizar estado de un reporte
     */
    public function updateReportStatus($reportId, $status, $revisorId = null, $comentarios = null) {
        try {
            // Validar estado
            if (!in_array($status, self::ESTADOS_VALIDOS)) {
                return [
                    'success' => false,
                    'message' => 'Estado inválido. Valores permitidos: ' . implode(', ', self::ESTADOS_VALIDOS)
                ];
            }
            
            $sql = "UPDATE reportes SET 
                    estado = ?, 
                    revisado_por = ?, 
                    comentarios_revision = ?,
                    fecha_revision = CURRENT_TIMESTAMP
                    WHERE id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("sisi", $status, $revisorId, $comentarios, $reportId);
            
            if (!$stmt->execute()) {
                throw new Exception("Error actualizando reporte: " . $stmt->error);
            }
            
            if ($stmt->affected_rows === 0) {
                return [
                    'success' => false,
                    'message' => 'Reporte no encontrado'
                ];
            }
            
            $stmt->close();

            // Notificar cambio de estado
            $this->notifyReportEvent($reportId, 'estado', [
                'nuevo_estado' => $status,
                'revisor_id' => $revisorId,
                'comentarios' => $comentarios
            ]);

            return [
                'success' => true,
                'message' => 'Estado del reporte actualizado exitosamente'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al actualizar reporte: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Obtener estadísticas de reportes
     */
    public function getReportStats() {
        try {
            $sql = "SELECT 
                        tipo_reporte,
                        estado,
                        COUNT(*) as cantidad
                    FROM reportes 
                    GROUP BY tipo_reporte, estado";
            
            $result = $this->conn->query($sql);
            $stats = [];
            
            while ($row = $result->fetch_assoc()) {
                $stats[] = $row;
            }
            
            return [
                'success' => true,
                'stats' => $stats
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al obtener estadísticas: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Actualizar un reporte existente
     */
    public function updateReport($reportId, $data) {
        try {
            // Evitar logs de payload en producción
            
            // Verificar conexión a la base de datos
            if (!$this->conn || $this->conn->connect_error) {
                throw new Exception("Error de conexión a la base de datos");
            }
            
            // Verificar que el reporte existe y está pendiente, y obtener su tipo
            $sqlCheck = "SELECT id, estado, tipo_reporte FROM reportes WHERE id = ?";
            $stmtCheck = $this->conn->prepare($sqlCheck);
            $stmtCheck->bind_param("i", $reportId);
            $stmtCheck->execute();
            $resultCheck = $stmtCheck->get_result();
            
            if ($resultCheck->num_rows === 0) {
                return [
                    'success' => false,
                    'message' => 'Reporte no encontrado'
                ];
            }
            
            $report = $resultCheck->fetch_assoc();
            if ($report['estado'] !== 'pendiente') {
                return [
                    'success' => false,
                    'message' => 'Solo se pueden editar reportes pendientes'
                ];
            }
            
            $tipoReporte = $report['tipo_reporte'];
            $stmtCheck->close();
            
            // Sanitizar datos de entrada
            $data = $this->sanitizeInput($data);
            
            // Agregar el tipo de reporte a los datos para validación
            $data['tipo_reporte'] = $tipoReporte;
            
            // Validar campos ENUM
            $enumErrors = $this->validateEnumFields($data, $tipoReporte);
            if (!empty($enumErrors)) {
                return [
                    'success' => false,
                    'message' => 'Errores de validación: ' . implode(', ', $enumErrors)
                ];
            }
            
            // Validar campos específicos según tipo de reporte
            $validationErrors = $this->validateReportFields($data, $tipoReporte);
            if (!empty($validationErrors)) {
                return [
                    'success' => false,
                    'message' => 'Errores de validación: ' . implode(', ', $validationErrors)
                ];
            }
            
            // Preparar la consulta SQL de actualización
            $sql = "UPDATE reportes SET 
                    telefono_contacto = ?,
                    correo_contacto = ?,
                    tipo_pqr = ?,
                    asunto = ?, 
                    descripcion_general = ?,
                    fecha_evento = ?,
                    lugar_hallazgo = ?,
                    lugar_hallazgo_otro = ?,
                    tipo_hallazgo = ?,
                    descripcion_hallazgo = ?,
                    recomendaciones = ?,
                    estado_condicion = ?,
                    grado_criticidad = ?,
                    ubicacion_incidente = ?,
                    hora_evento = ?,
                    tipo_afectacion = ?,
                    descripcion_incidente = ?,
                    tipo_conversacion = ?,
                    sitio_evento_conversacion = ?,
                    lugar_hallazgo_conversacion = ?,
                    lugar_hallazgo_conversacion_otro = ?,
                    descripcion_conversacion = ?,
                    asunto_conversacion = ?,
                    actualizado_en = CURRENT_TIMESTAMP
                    WHERE id = ?";
            
            $stmt = $this->conn->prepare($sql);
            
            if (!$stmt) {
                throw new Exception("Error preparando la consulta: " . $this->conn->error);
            }
            
            // Extraer valores a variables para bind_param
            $telefono_contacto = $data['telefono_contacto'] ?? null;
            $correo_contacto = $data['correo_contacto'] ?? null;
            $tipo_pqr = $data['tipo_pqr'] ?? null;
            $asunto = $data['asunto'] ?? $data['asunto_conversacion'] ?? null;
            $descripcion_general = $data['descripcion_general'] ?? null;
            $fecha_evento = $data['fecha_evento'] ?? null;
            $lugar_hallazgo = $data['lugar_hallazgo'] ?? null;
            $lugar_hallazgo_otro = $data['lugar_hallazgo_otro'] ?? null;
            $tipo_hallazgo = $data['tipo_hallazgo'] ?? null;
            $descripcion_hallazgo = $data['descripcion_hallazgo'] ?? null;
            $recomendaciones = $data['recomendaciones'] ?? null;
            $estado_condicion = $data['estado_condicion'] ?? null;
            $grado_criticidad = $data['grado_criticidad'] ?? null;
            $ubicacion_incidente = $data['ubicacion_incidente'] ?? null;
            $hora_evento = $data['hora_evento'] ?? null;
            $tipo_afectacion = $data['tipo_afectacion'] ?? null;
            $descripcion_incidente = $data['descripcion_incidente'] ?? null;
            $tipo_conversacion = $data['tipo_conversacion'] ?? null;
            $sitio_evento_conversacion = $data['sitio_evento_conversacion'] ?? null;
            $lugar_hallazgo_conversacion = $data['lugar_hallazgo_conversacion'] ?? null;
            $lugar_hallazgo_conversacion_otro = $data['lugar_hallazgo_conversacion_otro'] ?? null;
            $descripcion_conversacion = $data['descripcion_conversacion'] ?? null;
            $asunto_conversacion = $data['asunto_conversacion'] ?? null;
            
            // Bind de parámetros
            $stmt->bind_param("sssssssssssssssssssssssi",
                $telefono_contacto,
                $correo_contacto,
                $tipo_pqr,
                $asunto,
                $descripcion_general,
                $fecha_evento,
                $lugar_hallazgo,
                $lugar_hallazgo_otro,
                $tipo_hallazgo,
                $descripcion_hallazgo,
                $recomendaciones,
                $estado_condicion,
                $grado_criticidad,
                $ubicacion_incidente,
                $hora_evento,
                $tipo_afectacion,
                $descripcion_incidente,
                $tipo_conversacion,
                $sitio_evento_conversacion,
                $lugar_hallazgo_conversacion,
                $lugar_hallazgo_conversacion_otro,
                $descripcion_conversacion,
                $asunto_conversacion,
                $reportId
            );
            
            // Ejecutar la consulta
            if (!$stmt->execute()) {
                throw new Exception("Error ejecutando la consulta: " . $stmt->error);
            }
            
            if ($stmt->affected_rows === 0) {
                return [
                    'success' => false,
                    'message' => 'No se realizaron cambios en el reporte'
                ];
            }
            
            $stmt->close();
            
            return [
                'success' => true,
                'message' => 'Reporte actualizado exitosamente'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al actualizar el reporte: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Eliminar un reporte
     */
    public function deleteReport($reportId) {
        try {
            // Verificar que el reporte existe y está pendiente
            $sqlCheck = "SELECT id, estado FROM reportes WHERE id = ?";
            $stmtCheck = $this->conn->prepare($sqlCheck);
            $stmtCheck->bind_param("i", $reportId);
            $stmtCheck->execute();
            $resultCheck = $stmtCheck->get_result();
            
            if ($resultCheck->num_rows === 0) {
                return [
                    'success' => false,
                    'message' => 'Reporte no encontrado'
                ];
            }
            
            $report = $resultCheck->fetch_assoc();
            if ($report['estado'] !== 'pendiente') {
                return [
                    'success' => false,
                    'message' => 'Solo se pueden eliminar reportes pendientes'
                ];
            }
            
            $stmtCheck->close();
            
            // Eliminar evidencias asociadas primero
            $sqlEvidencias = "DELETE FROM evidencias WHERE id_reporte = ?";
            $stmtEvidencias = $this->conn->prepare($sqlEvidencias);
            $stmtEvidencias->bind_param("i", $reportId);
            $stmtEvidencias->execute();
            $stmtEvidencias->close();
            
            // Eliminar el reporte
            $sql = "DELETE FROM reportes WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("i", $reportId);
            
            if (!$stmt->execute()) {
                throw new Exception("Error eliminando reporte: " . $stmt->error);
            }
            
            if ($stmt->affected_rows === 0) {
                return [
                    'success' => false,
                    'message' => 'No se pudo eliminar el reporte'
                ];
            }
            
            $stmt->close();
            
            return [
                'success' => true,
                'message' => 'Reporte eliminado exitosamente'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al eliminar el reporte: ' . $e->getMessage()
            ];
        }
    }

    public function getDashboardStats() {
        try {
            // Obtener el período desde el parámetro GET (por defecto: 'month')
            $period = $_GET['period'] ?? 'month';
            
            // Determinar el intervalo numérico según el período
            switch ($period) {
                case 'quarter':
                    $intervalNum = 12; // 4 trimestres = 12 meses
                    break;
                case 'year':
                    $intervalNum = 24; // 2 años = 24 meses
                    break;
                case 'month':
                default:
                    $intervalNum = 6; // 6 meses
                    break;
            }
            
            // 1. Incidentes por mes con formato mejorado (dinámico según período)
            $sqlIncidentesPorMes = "
                SELECT 
                    DATE_FORMAT(fecha_evento, '%Y-%m') as mes,
                    DATE_FORMAT(fecha_evento, '%b') as mes_corto,
                    COUNT(CASE WHEN tipo_reporte = 'incidentes' THEN 1 END) as incidentes,
                    COUNT(CASE WHEN tipo_reporte = 'hallazgos' THEN 1 END) as hallazgos,
                    COUNT(CASE WHEN tipo_reporte = 'conversaciones' THEN 1 END) as conversaciones,
                    COUNT(CASE WHEN tipo_reporte = 'pqr' THEN 1 END) as pqr,
                    COUNT(*) as total_reportes
                FROM reportes 
                WHERE fecha_evento >= DATE_SUB(CURDATE(), INTERVAL $intervalNum MONTH)
                GROUP BY DATE_FORMAT(fecha_evento, '%Y-%m'), DATE_FORMAT(fecha_evento, '%b')
                ORDER BY mes ASC
            ";
            
            $resultIncidentesPorMes = $this->conn->query($sqlIncidentesPorMes);
            $incidentesPorMes = [];
            while ($row = $resultIncidentesPorMes->fetch_assoc()) {
                $incidentesPorMes[] = $row;
            }

            // 2. Distribución por tipo de incidente con colores
            $sqlDistribucionTipo = "
                SELECT 
                    tipo_reporte,
                    COUNT(*) as cantidad,
                    ROUND((COUNT(*) * 100.0) / (SELECT COUNT(*) FROM reportes), 2) as porcentaje
                FROM reportes 
                GROUP BY tipo_reporte
                ORDER BY cantidad DESC
            ";
            $resultDistribucionTipo = $this->conn->query($sqlDistribucionTipo);
            $distribucionTipo = [];
            $colores = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6'];
            $i = 0;
            while ($row = $resultDistribucionTipo->fetch_assoc()) {
                $row['color'] = $colores[$i % count($colores)];
                $distribucionTipo[] = $row;
                $i++;
            }

            // 3. Tendencias mensuales para gráfico de líneas (dinámico según período)
            $sqlTendencias = "
                SELECT 
                    DATE_FORMAT(fecha_evento, '%Y-%m') as mes,
                    DATE_FORMAT(fecha_evento, '%b') as mes_corto,
                    COUNT(CASE WHEN tipo_reporte = 'incidentes' THEN 1 END) as incidentes,
                    COUNT(CASE WHEN tipo_reporte = 'hallazgos' THEN 1 END) as hallazgos,
                    COUNT(CASE WHEN tipo_reporte = 'conversaciones' THEN 1 END) as conversaciones,
                    COUNT(CASE WHEN tipo_reporte = 'pqr' THEN 1 END) as pqr
                FROM reportes 
                WHERE fecha_evento >= DATE_SUB(CURDATE(), INTERVAL $intervalNum MONTH)
                GROUP BY DATE_FORMAT(fecha_evento, '%Y-%m'), DATE_FORMAT(fecha_evento, '%b')
                ORDER BY mes ASC
            ";
            $resultTendencias = $this->conn->query($sqlTendencias);
            $tendencias = [];
            while ($row = $resultTendencias->fetch_assoc()) {
                $tendencias[] = $row;
            }

            // 4. KPIs principales mejorados
            $sqlKPIs = "
                SELECT 
                    COUNT(*) as total_reportes,
                    COUNT(CASE WHEN tipo_reporte = 'incidentes' THEN 1 END) as total_incidentes,
                    COUNT(CASE WHEN tipo_reporte = 'hallazgos' THEN 1 END) as total_hallazgos,
                    COUNT(CASE WHEN tipo_reporte = 'conversaciones' THEN 1 END) as total_conversaciones,
                    COUNT(CASE WHEN tipo_reporte = 'pqr' THEN 1 END) as total_pqr,
                    COUNT(CASE WHEN estado = 'pendiente' THEN 1 END) as pendientes,
                    COUNT(CASE WHEN estado = 'aprobado' THEN 1 END) as aprobados,
                    COUNT(CASE WHEN estado = 'rechazado' THEN 1 END) as rechazados,
                    COUNT(CASE WHEN estado = 'en_revision' THEN 1 END) as en_revision,
                    ROUND((COUNT(CASE WHEN estado = 'aprobado' THEN 1 END) * 100.0) / COUNT(*), 2) as tasa_aprobacion
                FROM reportes
            ";
            $resultKPIs = $this->conn->query($sqlKPIs);
            $kpis = $resultKPIs->fetch_assoc();

            // 5. Días sin accidentes (último incidente)
            $sqlUltimoIncidente = "
                SELECT 
                    COALESCE(DATEDIFF(CURDATE(), MAX(fecha_evento)), 0) as dias_sin_accidentes,
                    MAX(fecha_evento) as ultimo_incidente
                FROM reportes 
                WHERE tipo_reporte = 'incidentes'
            ";
            $resultUltimoIncidente = $this->conn->query($sqlUltimoIncidente);
            $ultimoIncidente = $resultUltimoIncidente->fetch_assoc();

            // 6. Métricas de seguridad (simuladas basadas en datos reales)
            $sqlMetricasSeguridad = "
                SELECT 
                    ROUND((COUNT(CASE WHEN estado = 'aprobado' THEN 1 END) * 100.0) / COUNT(*), 0) as cumplimiento_epp,
                    ROUND((COUNT(CASE WHEN tipo_reporte = 'hallazgos' THEN 1 END) * 100.0) / COUNT(*), 0) as inspecciones,
                    ROUND((COUNT(CASE WHEN tipo_reporte = 'conversaciones' THEN 1 END) * 100.0) / COUNT(*), 0) as capacitacion,
                    ROUND((COUNT(CASE WHEN estado != 'rechazado' THEN 1 END) * 100.0) / COUNT(*), 0) as documentacion,
                    ROUND((COUNT(CASE WHEN estado = 'en_revision' THEN 1 END) * 100.0) / COUNT(*), 0) as procedimientos,
                    ROUND((COUNT(CASE WHEN estado = 'aprobado' THEN 1 END) * 100.0) / COUNT(*), 0) as auditorias
                FROM reportes
            ";
            $resultMetricasSeguridad = $this->conn->query($sqlMetricasSeguridad);
            $metricasSeguridad = $resultMetricasSeguridad->fetch_assoc();

            // 7. Estadísticas por criticidad (si existe el campo)
            $sqlCriticidad = "
                SELECT 
                    COALESCE(grado_criticidad, 'No especificada') as criticidad,
                    COUNT(*) as cantidad
                FROM reportes 
                GROUP BY grado_criticidad
                ORDER BY cantidad DESC
            ";
            $resultCriticidad = $this->conn->query($sqlCriticidad);
            $criticidad = [];
            while ($row = $resultCriticidad->fetch_assoc()) {
                $criticidad[] = $row;
            }

            return [
                'success' => true,
                'data' => [
                    'incidentesPorMes' => $incidentesPorMes,
                    'distribucionTipo' => $distribucionTipo,
                    'tendencias' => $tendencias,
                    'kpis' => $kpis,
                    'diasSinAccidentes' => $ultimoIncidente['dias_sin_accidentes'] ?? 0,
                    'ultimoIncidente' => $ultimoIncidente['ultimo_incidente'] ?? null,
                    'metricasSeguridad' => $metricasSeguridad,
                    'criticidad' => $criticidad
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al obtener estadísticas del dashboard: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Enviar notificación por correo y registrar en tabla notificaciones
     */
    public function notifyReportEvent(int $reportId, string $tipo, array $extra = []) : void {
        // Interceptar y suprimir warnings/notice locales para no activar el handler global (evita 500)
        $prevHandler = set_error_handler(function($severity, $message, $file, $line) {
            error_log("notifyReportEvent warning [$severity]: $message in " . basename($file) . ":$line");
            return true; // indicar que el warning fue manejado
        });
        try {
            // Obtener datos del reporte y usuario
            $sql = "SELECT r.id, r.tipo_reporte, r.asunto, r.asunto_conversacion, r.creado_en, r.estado, u.nombre, u.correo 
                    FROM reportes r JOIN usuarios u ON r.id_usuario = u.id WHERE r.id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param('i', $reportId);
            $stmt->execute();
            $res = $stmt->get_result();
            $rep = $res->fetch_assoc();
            $stmt->close();
            if (!$rep) { if ($prevHandler) { restore_error_handler(); } return; }

            // Destinatario principal: correo del usuario del reporte
            $destinatario = $rep['correo'] ?: '';
            // En pruebas, puede definirse MAIL_TEST_TO para redirigir envío
            $testTo = getenv('MAIL_TEST_TO') ?: null;

            $titulo = $rep['asunto'] ?: ($rep['asunto_conversacion'] ?: '(sin asunto)');
            $subject = '';
            $body = '';
            $attachments = [];
            
            if ($tipo === 'creacion') {
                $subject = "[HSEQ] Nuevo reporte #{$rep['id']} - {$rep['tipo_reporte']}";
                $body = "<p>Hola {$rep['nombre']},</p>
                         <p>Se ha creado tu reporte <strong>#{$rep['id']}</strong> de tipo <strong>{$rep['tipo_reporte']}</strong>.</p>
                         <p>Título: <strong>{$this->e($titulo)}</strong></p>
                         <p>Estado actual: <strong>{$rep['estado']}</strong></p>
                         <p>Fecha de creación: {$rep['creado_en']}</p>";
            } else if ($tipo === 'estado') {
                $estadoOriginal = $extra['nuevo_estado'] ?? '';
                $estadoEscapado = $this->e($estadoOriginal);
                $subject = "[HSEQ] Estado actualizado reporte #{$rep['id']} → {$estadoEscapado}";
                $body = "<p>Hola {$rep['nombre']},</p>
                         <p>El estado de tu reporte <strong>#{$rep['id']}</strong> ha cambiado a <strong>{$estadoEscapado}</strong>.</p>
                         <p>Título: <strong>{$this->e($titulo)}</strong></p>";
                if (!empty($extra['comentarios'])) {
                    $body .= "<p>Comentarios de revisión: {$this->e($extra['comentarios'])}</p>";
                }
                
            // Si el reporte fue aprobado o rechazado (cerrado), NO adjuntar PDF (requerido por el cliente)
                if (in_array($estadoOriginal, ['aprobado', 'rechazado'])) {
                    // Intencionalmente no se adjunta PDF para evitar demoras/errores; el frontend abrirá Gmail
                }
            } else if ($tipo === 'vencido') {
                $subject = "[HSEQ] Recordatorio: reporte #{$rep['id']} supera 30 días";
                $body = "<p>Hola {$rep['nombre']},</p>
                         <p>Tu reporte <strong>#{$rep['id']}</strong> continúa en estado <strong>{$rep['estado']}</strong> y han pasado más de 30 días desde su creación ({$rep['creado_en']}).</p>
                         <p>Por favor, realiza seguimiento o contacta a soporte.</p>";
            }
            $body .= "<hr/><p>Este es un mensaje automático. No responder.</p>";

            // Log de adjuntos
            try { error_log('Adjuntos a enviar: ' . count($attachments)); } catch (Exception $e) {}

            // Enviar correo: usar test si está configurado, de lo contrario enviar al destinatario real
            $sendTo = $testTo ?: $destinatario;
            if (!$sendTo) { $sendTo = 'soportehseq@meridian.com.co'; }
            $sendResult = send_email($sendTo, $subject, $body, null, $attachments);
            if (is_array($sendResult)) {
                error_log('Resultado envío correo HSEQ: ' . json_encode($sendResult));
            }

            // Registrar en notificaciones
            $sqlN = 'INSERT INTO notificaciones (id_reporte, destinatario, medio) VALUES (?, ?, "correo")';
            $stmtN = $this->conn->prepare($sqlN);
            if ($stmtN) {
                $stmtN->bind_param('is', $reportId, $sendTo);
                $stmtN->execute();
                $stmtN->close();
            }
        } catch (Exception $e) {
            error_log("Error en notifyReportEvent: " . $e->getMessage());
            // Silencioso, no romper flujo del reporte
        } finally {
            if ($prevHandler) { restore_error_handler(); }
        }
    }

    /**
     * Obtiene el PDF usando el endpoint público de descarga
     */
    private function fetchReportPDFViaEndpoint(int $reportId): ?string {
        try {
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $url = $scheme . '://' . $host . '/backend/api/reports/' . $reportId . '/pdf';

            // Usar cURL para obtener binario del PDF
            if (!function_exists('curl_init')) {
                error_log('cURL no está disponible para fetch del PDF');
                return null;
            }
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            // Propagar Authorization si está presente para evitar 401
            $headers = ['Accept: application/pdf'];
            if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
                $headers[] = 'Authorization: ' . $_SERVER['HTTP_AUTHORIZATION'];
            }
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            // Evitar problemas de certificados en entornos con self-signed (si aplica)
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            $response = curl_exec($ch);
            $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (curl_errno($ch)) {
                error_log('cURL error al obtener PDF: ' . curl_error($ch));
            }
            curl_close($ch);
            if ($httpCode === 200 && $response) {
                return $response;
            }
            error_log("Fetch PDF via endpoint falló con código HTTP: $httpCode");
            return null;
        } catch (Exception $e) {
            error_log('Excepción en fetchReportPDFViaEndpoint: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * API: Genera y almacena el PDF temporal y retorna su ruta/metadata
     */
    public function storeReportPDFTemp(int $reportId): array {
        try {
            $filePath = $this->generateAndStorePDFTemp($reportId);
            if (!$filePath || !file_exists($filePath)) {
                return [ 'success' => false, 'message' => 'No fue posible generar el PDF temporal' ];
            }
            return [
                'success' => true,
                'file' => basename($filePath),
                'path' => $filePath,
                'size' => filesize($filePath)
            ];
        } catch (Exception $e) {
            return [ 'success' => false, 'message' => 'Error generando PDF: ' . $e->getMessage() ];
        }
    }

    /**
     * Genera un PDF y lo guarda como archivo temporal en backend/uploads/tmp
     */
    private function generateAndStorePDFTemp(int $reportId): ?string {
        try {
            // Directorio preferente
            $uploadsDir = __DIR__ . '/../uploads/tmp';
            if (!is_dir($uploadsDir)) { @mkdir($uploadsDir, 0775, true); }
            // Fallback a sys_get_temp_dir()/hseq si no es escribible
            if (!is_dir($uploadsDir) || !is_writable($uploadsDir)) {
                $sysTmp = rtrim((string)sys_get_temp_dir(), DIRECTORY_SEPARATOR);
                $uploadsDir = $sysTmp . DIRECTORY_SEPARATOR . 'hseq';
                if (!is_dir($uploadsDir)) { @mkdir($uploadsDir, 0775, true); }
                if (!is_dir($uploadsDir) || !is_writable($uploadsDir)) {
                    error_log('Directorio temporal no disponible para PDF: ' . $uploadsDir);
                    return null;
                }
            }
            // Forzar generación local primero (evitar depender de endpoint)
            $pdfContent = $this->generateReportPDFContent($reportId);
            if (!$pdfContent) {
                error_log('generateReportPDFContent devolvió null, intentando endpoint de PDF');
                $pdfContent = $this->fetchReportPDFViaEndpoint($reportId);
            }
            if (!$pdfContent) { return null; }
            $file = $uploadsDir . '/reporte_hseq_' . $reportId . '_' . time() . '.pdf';
            $bytes = @file_put_contents($file, $pdfContent);
            if ($bytes === false || $bytes === 0 || !file_exists($file) || filesize($file) <= 0) {
                error_log('file_put_contents falló o tamaño 0: ' . $file);
                return null;
            }
            return $file;
        } catch (Exception $e) {
            error_log('Excepción en generateAndStorePDFTemp: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Genera el contenido PDF del reporte y lo retorna como string binario
     */
    private function generateReportPDFContent(int $reportId): ?string {
        try {
            // Obtener datos completos del reporte (copiado de pdfController)
            $stmt = $this->conn->prepare("
                SELECT r.*, u.nombre as nombre_usuario, u.proyecto as proyecto_usuario
                FROM reportes r 
                JOIN usuarios u ON r.id_usuario = u.id 
                WHERE r.id = ?
            ");
            
            if (!$stmt) {
                error_log("Error preparando query de reporte: " . $this->conn->error);
                return null;
            }
            
            $stmt->bind_param('i', $reportId);
            $stmt->execute();
            $reporte = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if (!$reporte) {
                error_log("Reporte no encontrado para generar PDF: ID=$reportId");
                return null;
            }
            
            // Obtener evidencias del reporte
            try {
                $stmt = $this->conn->prepare("
                    SELECT * FROM evidencias 
                    WHERE id_reporte = ? 
                    ORDER BY creado_en ASC
                ");
                
                if ($stmt) {
                    $stmt->bind_param('i', $reportId);
                    $stmt->execute();
                    $evidencias = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                    $stmt->close();
                    $reporte['evidencias'] = $evidencias;
                } else {
                    $reporte['evidencias'] = [];
                }
            } catch (Exception $e) {
                error_log("Error obteniendo evidencias: " . $e->getMessage());
                $reporte['evidencias'] = [];
            }
            
            // Generar HTML simplificado del reporte
            $html = $this->generateSimplePDFHTML($reporte);
            
            // Generar PDF usando TCPDF con carga segura
            if (!class_exists('TCPDF')) {
                $base = __DIR__ . '/../vendor/tcpdf';
                $pathInclude = $base . '/include/tcpdf.php';
                $pathWrapper = $base . '/tcpdf.php';
                $pathBootstrap = $base . '/tcpdf_include.php';

                $loaded = false;
                // Preferir incluir directamente la clase si existe
                if (file_exists($pathInclude)) {
                    require_once $pathInclude;
                    $loaded = class_exists('TCPDF');
                } elseif (file_exists($pathBootstrap)) {
                    require_once $pathBootstrap;
                    $loaded = class_exists('TCPDF');
                } elseif (file_exists($pathWrapper) && file_exists($pathInclude)) {
                    // Solo cargar el wrapper si también existe su include
                    require_once $pathWrapper;
                    $loaded = class_exists('TCPDF');
                }

                if (!$loaded) {
                    error_log('No fue posible cargar TCPDF de forma segura (falta include/tcpdf.php).');
                    return null;
                }
            }
            
            // Verificar que las constantes estén definidas
            if (!defined('PDF_PAGE_ORIENTATION')) {
                define('PDF_PAGE_ORIENTATION', 'P');
            }
            if (!defined('PDF_UNIT')) {
                define('PDF_UNIT', 'mm');
            }
            if (!defined('PDF_PAGE_FORMAT')) {
                define('PDF_PAGE_FORMAT', 'A4');
            }
            
            // Crear instancia de TCPDF
            $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
            
            // Configurar documento
            $pdf->SetCreator('Sistema HSEQ Meridian');
            $pdf->SetAuthor('Meridian Consulting LTDA');
            $pdf->SetTitle('Reporte HSEQ #' . $reporte['id']);
            $pdf->SetSubject('Reporte de Seguridad, Salud Ocupacional y Medio Ambiente');
            
            // Configurar márgenes
            $pdf->SetMargins(15, 15, 15);
            $pdf->SetHeaderMargin(5);
            $pdf->SetFooterMargin(10);
            
            // Configurar auto page breaks
            $pdf->SetAutoPageBreak(TRUE, 25);
            
            // Desactivar header y footer por defecto
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);
            
            // Agregar página
            $pdf->AddPage();
            
            // Escribir HTML
            $pdf->writeHTML($html, true, false, true, false, '');
            
            // Retornar PDF como string en lugar de descargarlo
            return $pdf->Output('', 'S'); // 'S' retorna el documento como string
            
        } catch (Exception $e) {
            error_log("Error generando contenido PDF: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
            return null;
        }
    }
    
    /**
     * Genera HTML simplificado para el PDF
     */
    private function generateSimplePDFHTML($reporte): string {
        $titulo = $reporte['asunto'] ?: ($reporte['asunto_conversacion'] ?: 'Sin título');
        $evidencias = $reporte['evidencias'] ?? [];
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; font-size: 12px; }
                .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #2c5aa0; padding-bottom: 20px; }
                .header h1 { color: #2c5aa0; margin: 0; font-size: 24px; }
                .section { margin-bottom: 25px; border: 1px solid #ddd; border-radius: 5px; }
                .section h3 { background-color: #f8f9fa; padding: 12px; margin: 0; color: #2c5aa0; }
                .section-content { padding: 15px; }
                .info-row { margin-bottom: 8px; }
                .info-label { font-weight: bold; color: #333; }
                .info-value { color: #666; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>REPORTE HSEQ</h1>
                <h2>MERIDIAN CONSULTING LTDA</h2>
            </div>
            
            <div class="section">
                <h3>INFORMACIÓN GENERAL</h3>
                <div class="section-content">
                    <div class="info-row">
                        <span class="info-label">ID del Reporte:</span>
                        <span class="info-value">' . htmlspecialchars($reporte['id']) . '</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Tipo de Reporte:</span>
                        <span class="info-value">' . htmlspecialchars($reporte['tipo_reporte']) . '</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Estado:</span>
                        <span class="info-value">' . htmlspecialchars($reporte['estado']) . '</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Usuario:</span>
                        <span class="info-value">' . htmlspecialchars($reporte['nombre_usuario']) . '</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Fecha del Evento:</span>
                        <span class="info-value">' . htmlspecialchars($reporte['fecha_evento'] ?? 'N/A') . '</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Título:</span>
                        <span class="info-value">' . htmlspecialchars($titulo) . '</span>
                    </div>
                </div>
            </div>';
            
        // Descripción según tipo
        if (!empty($reporte['descripcion_hallazgo'])) {
            $html .= '
            <div class="section">
                <h3>DESCRIPCIÓN</h3>
                <div class="section-content">
                    <p>' . nl2br(htmlspecialchars($reporte['descripcion_hallazgo'])) . '</p>
                </div>
            </div>';
        } elseif (!empty($reporte['descripcion_incidente'])) {
            $html .= '
            <div class="section">
                <h3>DESCRIPCIÓN</h3>
                <div class="section-content">
                    <p>' . nl2br(htmlspecialchars($reporte['descripcion_incidente'])) . '</p>
                </div>
            </div>';
        } elseif (!empty($reporte['descripcion_conversacion'])) {
            $html .= '
            <div class="section">
                <h3>DESCRIPCIÓN</h3>
                <div class="section-content">
                    <p>' . nl2br(htmlspecialchars($reporte['descripcion_conversacion'])) . '</p>
                </div>
            </div>';
        }
        
        // Comentarios de revisión
        if (!empty($reporte['comentarios_revision'])) {
            $html .= '
            <div class="section">
                <h3>COMENTARIOS DE REVISIÓN</h3>
                <div class="section-content">
                    <p>' . nl2br(htmlspecialchars($reporte['comentarios_revision'])) . '</p>
                </div>
            </div>';
        }
        
        // Evidencias
        if (!empty($evidencias)) {
            $html .= '
            <div class="section">
                <h3>EVIDENCIAS</h3>
                <div class="section-content">
                    <p>Se han adjuntado ' . count($evidencias) . ' evidencia(s) a este reporte.</p>
                </div>
            </div>';
        }
        
        $html .= '
        </body>
        </html>';
        
        return $html;
    }

    private function e(string $s): string {
        return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    }
}
?> 